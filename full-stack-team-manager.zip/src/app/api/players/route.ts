import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { players } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const allPlayers = await db.select().from(players).orderBy(players.number);
    return NextResponse.json(allPlayers);
  } catch (error) {
    console.error("Get players error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const body = await request.json();
    const [player] = await db.insert(players).values(body).returning();
    return NextResponse.json(player, { status: 201 });
  } catch (error) {
    console.error("Create player error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
