import { NextResponse } from "next/server";
import { pool } from "@/db";
import { seed } from "@/db/seed";

export async function GET() {
  try {
    // Create enums
    await pool.query(`
      DO $$ BEGIN
        CREATE TYPE player_status AS ENUM ('available', 'injured', 'suspended', 'resting');
      EXCEPTION WHEN duplicate_object THEN null;
      END $$;
    `);
    
    await pool.query(`
      DO $$ BEGIN
        CREATE TYPE position AS ENUM ('goalkeeper', 'defender', 'midfielder', 'forward');
      EXCEPTION WHEN duplicate_object THEN null;
      END $$;
    `);
    
    await pool.query(`
      DO $$ BEGIN
        CREATE TYPE match_status AS ENUM ('upcoming', 'live', 'completed', 'cancelled');
      EXCEPTION WHEN duplicate_object THEN null;
      END $$;
    `);
    
    await pool.query(`
      DO $$ BEGIN
        CREATE TYPE event_type AS ENUM ('training', 'meeting', 'social', 'travel', 'medical', 'other');
      EXCEPTION WHEN duplicate_object THEN null;
      END $$;
    `);

    // Create tables
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'manager',
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS players (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        number INTEGER NOT NULL,
        position position NOT NULL,
        status player_status NOT NULL DEFAULT 'available',
        age INTEGER NOT NULL,
        nationality VARCHAR(100) NOT NULL,
        image_url TEXT,
        goals INTEGER NOT NULL DEFAULT 0,
        assists INTEGER NOT NULL DEFAULT 0,
        appearances INTEGER NOT NULL DEFAULT 0,
        injury_note TEXT,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL,
        updated_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS matches (
        id SERIAL PRIMARY KEY,
        opponent VARCHAR(255) NOT NULL,
        venue VARCHAR(255) NOT NULL,
        date TIMESTAMP NOT NULL,
        status match_status NOT NULL DEFAULT 'upcoming',
        home_score INTEGER,
        away_score INTEGER,
        competition VARCHAR(255) NOT NULL,
        is_home BOOLEAN NOT NULL DEFAULT true,
        notes TEXT,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS squad_selections (
        id SERIAL PRIMARY KEY,
        match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
        player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
        is_starter BOOLEAN NOT NULL DEFAULT false,
        position_override VARCHAR(50),
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS events (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        type event_type NOT NULL,
        date TIMESTAMP NOT NULL,
        end_date TIMESTAMP,
        location VARCHAR(255),
        is_all_day BOOLEAN NOT NULL DEFAULT false,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL,
        updated_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    // Run seed
    await seed();

    return NextResponse.json({ 
      success: true, 
      message: "Database initialized and seeded successfully!" 
    });
  } catch (error) {
    console.error("Init error:", error);
    return NextResponse.json({ 
      error: "Initialization failed", 
      details: String(error) 
    }, { status: 500 });
  }
}

export async function POST() {
  return GET();
}
