import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { squadSelections, players } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { id } = await params;
    const matchId = parseInt(id);

    const selections = await db
      .select({
        id: squadSelections.id,
        matchId: squadSelections.matchId,
        playerId: squadSelections.playerId,
        isStarter: squadSelections.isStarter,
        positionOverride: squadSelections.positionOverride,
        playerName: players.name,
        playerNumber: players.number,
        playerPosition: players.position,
        playerStatus: players.status,
      })
      .from(squadSelections)
      .innerJoin(players, eq(squadSelections.playerId, players.id))
      .where(eq(squadSelections.matchId, matchId));

    return NextResponse.json(selections);
  } catch (error) {
    console.error("Get squad error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { id } = await params;
    const matchId = parseInt(id);
    const { selections } = await request.json();

    // Delete existing selections
    await db
      .delete(squadSelections)
      .where(eq(squadSelections.matchId, matchId));

    // Insert new selections
    if (selections && selections.length > 0) {
      await db.insert(squadSelections).values(
        selections.map((s: { playerId: number; isStarter: boolean; positionOverride?: string }) => ({
          matchId,
          playerId: s.playerId,
          isStarter: s.isStarter,
          positionOverride: s.positionOverride || null,
        }))
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Update squad error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
