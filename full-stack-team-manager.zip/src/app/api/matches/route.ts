import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { matches } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const allMatches = await db.select().from(matches).orderBy(desc(matches.date));
    return NextResponse.json(allMatches);
  } catch (error) {
    console.error("Get matches error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const body = await request.json();
    const [match] = await db.insert(matches).values(body).returning();
    return NextResponse.json(match, { status: 201 });
  } catch (error) {
    console.error("Create match error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
