import { NextResponse } from "next/server";
import { db } from "@/db";
import { players, matches, events } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { eq, gte, and, asc, desc } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const now = new Date();

    const allPlayers = await db.select().from(players);
    const upcomingMatches = await db
      .select()
      .from(matches)
      .where(and(eq(matches.status, "upcoming"), gte(matches.date, now)))
      .orderBy(asc(matches.date))
      .limit(3);

    const recentMatches = await db
      .select()
      .from(matches)
      .where(eq(matches.status, "completed"))
      .orderBy(desc(matches.date))
      .limit(3);

    const upcomingEvents = await db
      .select()
      .from(events)
      .where(gte(events.date, now))
      .orderBy(asc(events.date))
      .limit(5);

    const totalPlayers = allPlayers.length;
    const availablePlayers = allPlayers.filter((p) => p.status === "available").length;
    const injuredPlayers = allPlayers.filter((p) => p.status === "injured").length;
    const suspendedPlayers = allPlayers.filter((p) => p.status === "suspended").length;

    const nextMatch = upcomingMatches[0] || null;

    return NextResponse.json({
      stats: {
        totalPlayers,
        availablePlayers,
        injuredPlayers,
        suspendedPlayers,
      },
      nextMatch,
      upcomingMatches,
      recentMatches,
      upcomingEvents,
      injuredPlayersList: allPlayers.filter((p) => p.status === "injured"),
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
