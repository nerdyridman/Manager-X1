"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Users,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  ChevronDown,
  User,
  Goal,
  Loader2,
} from "lucide-react";
import Modal from "@/components/ui/Modal";
import StatusBadge from "@/components/ui/StatusBadge";
import EmptyState from "@/components/ui/EmptyState";
import SkeletonCard from "@/components/ui/SkeletonCard";

interface Player {
  id: number;
  name: string;
  number: number;
  position: string;
  status: string;
  age: number;
  nationality: string;
  goals: number;
  assists: number;
  appearances: number;
  injuryNote: string | null;
}

const positions = ["goalkeeper", "defender", "midfielder", "forward"];
const statuses = ["available", "injured", "suspended", "resting"];

export default function PlayersPage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [positionFilter, setPositionFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editPlayer, setEditPlayer] = useState<Player | null>(null);
  const [detailPlayer, setDetailPlayer] = useState<Player | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState<number | null>(null);

  const [form, setForm] = useState({
    name: "",
    number: "",
    position: "midfielder",
    status: "available",
    age: "",
    nationality: "",
    goals: "0",
    assists: "0",
    appearances: "0",
    injuryNote: "",
  });

  const fetchPlayers = useCallback(async () => {
    const res = await fetch("/api/players");
    if (res.ok) {
      const data = await res.json();
      setPlayers(data);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchPlayers();
  }, [fetchPlayers]);

  const openCreate = () => {
    setEditPlayer(null);
    setForm({
      name: "",
      number: "",
      position: "midfielder",
      status: "available",
      age: "",
      nationality: "",
      goals: "0",
      assists: "0",
      appearances: "0",
      injuryNote: "",
    });
    setModalOpen(true);
  };

  const openEdit = (player: Player) => {
    setEditPlayer(player);
    setForm({
      name: player.name,
      number: String(player.number),
      position: player.position,
      status: player.status,
      age: String(player.age),
      nationality: player.nationality,
      goals: String(player.goals),
      assists: String(player.assists),
      appearances: String(player.appearances),
      injuryNote: player.injuryNote || "",
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const body = {
      name: form.name,
      number: parseInt(form.number),
      position: form.position,
      status: form.status,
      age: parseInt(form.age),
      nationality: form.nationality,
      goals: parseInt(form.goals),
      assists: parseInt(form.assists),
      appearances: parseInt(form.appearances),
      injuryNote: form.injuryNote || null,
    };

    if (editPlayer) {
      // Optimistic update
      setPlayers((prev) =>
        prev.map((p) =>
          p.id === editPlayer.id ? { ...p, ...body } : p
        )
      );
      setModalOpen(false);

      const res = await fetch(`/api/players/${editPlayer.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) await fetchPlayers();
    } else {
      const res = await fetch("/api/players", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        const newPlayer = await res.json();
        setPlayers((prev) => [...prev, newPlayer]);
      }
      setModalOpen(false);
    }
    setSaving(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to remove this player?")) return;
    setDeleting(id);

    // Optimistic update
    setPlayers((prev) => prev.filter((p) => p.id !== id));

    const res = await fetch(`/api/players/${id}`, { method: "DELETE" });
    if (!res.ok) await fetchPlayers();
    setDeleting(null);
  };

  const filtered = players.filter((p) => {
    if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (positionFilter && p.position !== positionFilter) return false;
    if (statusFilter && p.status !== statusFilter) return false;
    return true;
  });

  const positionIcons: Record<string, string> = {
    goalkeeper: "🧤",
    defender: "🛡️",
    midfielder: "⚙️",
    forward: "⚡",
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-200 rounded w-36 animate-pulse-subtle" />
          <div className="h-10 bg-gray-200 rounded w-32 animate-pulse-subtle" />
        </div>
        <SkeletonCard count={6} />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Players</h1>
          <p className="text-gray-500 mt-1">
            {players.length} players in squad
          </p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors shadow-lg shadow-blue-600/20"
        >
          <Plus size={18} />
          Add Player
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            size={18}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
          />
          <input
            type="text"
            placeholder="Search players..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all text-sm"
          />
        </div>
        <select
          value={positionFilter}
          onChange={(e) => setPositionFilter(e.target.value)}
          className="px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm text-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
        >
          <option value="">All Positions</option>
          {positions.map((p) => (
            <option key={p} value={p}>
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </option>
          ))}
        </select>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm text-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
        >
          <option value="">All Status</option>
          {statuses.map((s) => (
            <option key={s} value={s}>
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </option>
          ))}
        </select>
      </div>

      {/* Player Grid */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={<Users size={48} />}
          title="No players found"
          description={
            search || positionFilter || statusFilter
              ? "Try adjusting your filters"
              : "Add your first player to get started"
          }
          action={
            !search && !positionFilter && !statusFilter ? (
              <button
                onClick={openCreate}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors"
              >
                Add Player
              </button>
            ) : undefined
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((player) => (
            <div
              key={player.id}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer group"
              onClick={() => setDetailPlayer(player)}
            >
              <div className="p-5">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-md">
                      {player.number}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{player.name}</h3>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-sm text-gray-500">
                          {positionIcons[player.position]}{" "}
                          {player.position.charAt(0).toUpperCase() +
                            player.position.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <StatusBadge status={player.status} />
                </div>

                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="bg-gray-50 rounded-lg p-2 text-center">
                    <p className="text-xs text-gray-400">Goals</p>
                    <p className="font-bold text-gray-900">{player.goals}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2 text-center">
                    <p className="text-xs text-gray-400">Assists</p>
                    <p className="font-bold text-gray-900">{player.assists}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2 text-center">
                    <p className="text-xs text-gray-400">Apps</p>
                    <p className="font-bold text-gray-900">
                      {player.appearances}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>
                    {player.nationality} • Age {player.age}
                  </span>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openEdit(player);
                      }}
                      className="p-1.5 hover:bg-blue-50 rounded-lg text-blue-600 transition-colors"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(player.id);
                      }}
                      className="p-1.5 hover:bg-red-50 rounded-lg text-red-500 transition-colors"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>

                {player.status === "injured" && player.injuryNote && (
                  <div className="mt-3 p-3 bg-red-50 rounded-lg border border-red-100">
                    <p className="text-xs text-red-600">{player.injuryNote}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Player Detail Modal */}
      <Modal
        isOpen={!!detailPlayer}
        onClose={() => setDetailPlayer(null)}
        title="Player Details"
        size="md"
      >
        {detailPlayer && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-2xl shadow-lg">
                {detailPlayer.number}
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  {detailPlayer.name}
                </h3>
                <p className="text-gray-500 capitalize">
                  {positionIcons[detailPlayer.position]}{" "}
                  {detailPlayer.position}
                </p>
                <StatusBadge status={detailPlayer.status} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-xs text-gray-400 mb-1">Nationality</p>
                <p className="font-semibold">{detailPlayer.nationality}</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-xs text-gray-400 mb-1">Age</p>
                <p className="font-semibold">{detailPlayer.age}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <p className="text-xs text-blue-400 mb-1">Goals</p>
                <p className="text-2xl font-bold text-blue-700">
                  {detailPlayer.goals}
                </p>
              </div>
              <div className="bg-purple-50 rounded-xl p-4 text-center">
                <p className="text-xs text-purple-400 mb-1">Assists</p>
                <p className="text-2xl font-bold text-purple-700">
                  {detailPlayer.assists}
                </p>
              </div>
              <div className="bg-emerald-50 rounded-xl p-4 text-center">
                <p className="text-xs text-emerald-400 mb-1">Appearances</p>
                <p className="text-2xl font-bold text-emerald-700">
                  {detailPlayer.appearances}
                </p>
              </div>
            </div>

            {detailPlayer.injuryNote && (
              <div className="bg-red-50 rounded-xl p-4 border border-red-100">
                <p className="text-sm font-medium text-red-700 mb-1">
                  Injury Note
                </p>
                <p className="text-sm text-red-600">{detailPlayer.injuryNote}</p>
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setDetailPlayer(null);
                  openEdit(detailPlayer);
                }}
                className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors"
              >
                Edit Player
              </button>
              <button
                onClick={() => {
                  setDetailPlayer(null);
                  handleDelete(detailPlayer.id);
                }}
                className="px-6 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl font-medium transition-colors"
              >
                Remove
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Create/Edit Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editPlayer ? "Edit Player" : "Add New Player"}
        size="lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name *
              </label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Squad Number *
              </label>
              <input
                type="number"
                value={form.number}
                onChange={(e) => setForm({ ...form, number: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
                min={1}
                max={99}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Position *
              </label>
              <select
                value={form.position}
                onChange={(e) => setForm({ ...form, position: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              >
                {positions.map((p) => (
                  <option key={p} value={p}>
                    {p.charAt(0).toUpperCase() + p.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status *
              </label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              >
                {statuses.map((s) => (
                  <option key={s} value={s}>
                    {s.charAt(0).toUpperCase() + s.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Age *
              </label>
              <input
                type="number"
                value={form.age}
                onChange={(e) => setForm({ ...form, age: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
                min={15}
                max={50}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nationality *
              </label>
              <input
                type="text"
                value={form.nationality}
                onChange={(e) =>
                  setForm({ ...form, nationality: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Goals
              </label>
              <input
                type="number"
                value={form.goals}
                onChange={(e) => setForm({ ...form, goals: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                min={0}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Assists
              </label>
              <input
                type="number"
                value={form.assists}
                onChange={(e) => setForm({ ...form, assists: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                min={0}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Appearances
              </label>
              <input
                type="number"
                value={form.appearances}
                onChange={(e) =>
                  setForm({ ...form, appearances: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                min={0}
              />
            </div>
          </div>

          {form.status === "injured" && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Injury Note
              </label>
              <textarea
                value={form.injuryNote}
                onChange={(e) =>
                  setForm({ ...form, injuryNote: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                rows={2}
                placeholder="Describe the injury..."
              />
            </div>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {saving && <Loader2 size={16} className="animate-spin" />}
              {editPlayer ? "Update Player" : "Add Player"}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
