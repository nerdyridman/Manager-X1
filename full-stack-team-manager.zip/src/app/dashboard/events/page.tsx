"use client";

import { useState, useEffect, useCallback } from "react";
import {
  CalendarDays,
  Plus,
  MapPin,
  Clock,
  Edit2,
  Trash2,
  Loader2,
  Tag,
} from "lucide-react";
import Modal from "@/components/ui/Modal";
import StatusBadge from "@/components/ui/StatusBadge";
import EmptyState from "@/components/ui/EmptyState";
import SkeletonCard from "@/components/ui/SkeletonCard";
import { format, isPast, isToday, isTomorrow } from "date-fns";

interface Event {
  id: number;
  title: string;
  description: string | null;
  type: string;
  date: string;
  endDate: string | null;
  location: string | null;
  isAllDay: boolean;
}

const eventTypes = [
  "training",
  "meeting",
  "social",
  "travel",
  "medical",
  "other",
];

const typeIcons: Record<string, string> = {
  training: "🏃",
  meeting: "📋",
  social: "🎉",
  travel: "✈️",
  medical: "🏥",
  other: "📌",
};

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editEvent, setEditEvent] = useState<Event | null>(null);
  const [saving, setSaving] = useState(false);
  const [typeFilter, setTypeFilter] = useState("");

  const [form, setForm] = useState({
    title: "",
    description: "",
    type: "training",
    date: "",
    endDate: "",
    location: "",
    isAllDay: false,
  });

  const fetchEvents = useCallback(async () => {
    const res = await fetch("/api/events");
    if (res.ok) {
      const data = await res.json();
      setEvents(data);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const openCreate = () => {
    setEditEvent(null);
    setForm({
      title: "",
      description: "",
      type: "training",
      date: "",
      endDate: "",
      location: "",
      isAllDay: false,
    });
    setModalOpen(true);
  };

  const openEdit = (event: Event) => {
    setEditEvent(event);
    setForm({
      title: event.title,
      description: event.description || "",
      type: event.type,
      date: event.date.slice(0, 16),
      endDate: event.endDate ? event.endDate.slice(0, 16) : "",
      location: event.location || "",
      isAllDay: event.isAllDay,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const body = {
      title: form.title,
      description: form.description || null,
      type: form.type,
      date: new Date(form.date).toISOString(),
      endDate: form.endDate ? new Date(form.endDate).toISOString() : null,
      location: form.location || null,
      isAllDay: form.isAllDay,
    };

    if (editEvent) {
      setEvents((prev) =>
        prev.map((ev) => (ev.id === editEvent.id ? { ...ev, ...body } : ev))
      );
      setModalOpen(false);

      const res = await fetch(`/api/events/${editEvent.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) await fetchEvents();
    } else {
      const res = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        const newEvent = await res.json();
        setEvents((prev) => [...prev, newEvent].sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        ));
      }
      setModalOpen(false);
    }
    setSaving(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this event?")) return;
    setEvents((prev) => prev.filter((ev) => ev.id !== id));
    const res = await fetch(`/api/events/${id}`, { method: "DELETE" });
    if (!res.ok) await fetchEvents();
  };

  const filtered = typeFilter
    ? events.filter((e) => e.type === typeFilter)
    : events;

  const upcomingEvents = filtered.filter(
    (e) => !isPast(new Date(e.date)) || isToday(new Date(e.date))
  );
  const pastEvents = filtered.filter(
    (e) => isPast(new Date(e.date)) && !isToday(new Date(e.date))
  );

  const getDateLabel = (date: string) => {
    const d = new Date(date);
    if (isToday(d)) return "Today";
    if (isTomorrow(d)) return "Tomorrow";
    return format(d, "EEEE, MMM d");
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-200 rounded w-36 animate-pulse-subtle" />
          <div className="h-10 bg-gray-200 rounded w-32 animate-pulse-subtle" />
        </div>
        <SkeletonCard count={5} />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Events</h1>
          <p className="text-gray-500 mt-1">
            {events.length} events scheduled
          </p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors shadow-lg shadow-blue-600/20"
        >
          <Plus size={18} />
          Add Event
        </button>
      </div>

      {/* Type Filter */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setTypeFilter("")}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            !typeFilter
              ? "bg-blue-600 text-white shadow-sm"
              : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          All
        </button>
        {eventTypes.map((type) => (
          <button
            key={type}
            onClick={() => setTypeFilter(type === typeFilter ? "" : type)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all capitalize flex items-center gap-1.5 ${
              typeFilter === type
                ? "bg-blue-600 text-white shadow-sm"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {typeIcons[type]} {type}
          </button>
        ))}
      </div>

      {/* Upcoming Events */}
      {upcomingEvents.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
            Upcoming
          </h2>
          <div className="space-y-3">
            {upcomingEvents.map((event) => (
              <div
                key={event.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all p-5 group"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gray-50 rounded-xl flex flex-col items-center justify-center border border-gray-100 shrink-0">
                    <span className="text-xs font-bold text-blue-600">
                      {format(new Date(event.date), "MMM")}
                    </span>
                    <span className="text-lg font-bold text-gray-900 leading-none">
                      {format(new Date(event.date), "d")}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-lg">{typeIcons[event.type]}</span>
                      <StatusBadge status={event.type} />
                      {isToday(new Date(event.date)) && (
                        <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                          Today
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-bold text-gray-900">
                      {event.title}
                    </h3>
                    {event.description && (
                      <p className="text-sm text-gray-500 mt-0.5 line-clamp-2">
                        {event.description}
                      </p>
                    )}
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Clock size={13} />
                        {event.isAllDay
                          ? "All Day"
                          : format(new Date(event.date), "h:mm a")}
                        {event.endDate &&
                          !event.isAllDay &&
                          ` — ${format(new Date(event.endDate), "h:mm a")}`}
                      </span>
                      {event.location && (
                        <span className="flex items-center gap-1">
                          <MapPin size={13} />
                          {event.location}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEdit(event)}
                      className="p-2 hover:bg-blue-50 rounded-lg text-blue-600 transition-colors"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => handleDelete(event.id)}
                      className="p-2 hover:bg-red-50 rounded-lg text-red-500 transition-colors"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Past Events */}
      {pastEvents.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
            Past Events
          </h2>
          <div className="space-y-3">
            {pastEvents.map((event) => (
              <div
                key={event.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 opacity-70 hover:opacity-100 transition-all group"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gray-50 rounded-xl flex flex-col items-center justify-center border border-gray-100 shrink-0">
                    <span className="text-xs font-bold text-gray-400">
                      {format(new Date(event.date), "MMM")}
                    </span>
                    <span className="text-lg font-bold text-gray-400 leading-none">
                      {format(new Date(event.date), "d")}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-lg">{typeIcons[event.type]}</span>
                      <StatusBadge status={event.type} />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-600">
                      {event.title}
                    </h3>
                    <div className="flex flex-wrap items-center gap-3 mt-1 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Clock size={13} />
                        {format(new Date(event.date), "MMM d, h:mm a")}
                      </span>
                      {event.location && (
                        <span className="flex items-center gap-1">
                          <MapPin size={13} />
                          {event.location}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEdit(event)}
                      className="p-2 hover:bg-blue-50 rounded-lg text-blue-600 transition-colors"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => handleDelete(event.id)}
                      className="p-2 hover:bg-red-50 rounded-lg text-red-500 transition-colors"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {filtered.length === 0 && (
        <EmptyState
          icon={<CalendarDays size={48} />}
          title="No events found"
          description={
            typeFilter
              ? "No events match your filter. Try a different type."
              : "Plan your first event to keep your team organized"
          }
          action={
            !typeFilter ? (
              <button
                onClick={openCreate}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors"
              >
                Create Event
              </button>
            ) : undefined
          }
        />
      )}

      {/* Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editEvent ? "Edit Event" : "Create Event"}
        size="lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Title *
            </label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              required
              placeholder="Event title"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Type *
              </label>
              <select
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              >
                {eventTypes.map((t) => (
                  <option key={t} value={t}>
                    {typeIcons[t]} {t.charAt(0).toUpperCase() + t.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location
              </label>
              <input
                type="text"
                value={form.location}
                onChange={(e) =>
                  setForm({ ...form, location: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                placeholder="Event location"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date & Time *
              </label>
              <input
                type="datetime-local"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Date & Time
              </label>
              <input
                type="datetime-local"
                value={form.endDate}
                onChange={(e) =>
                  setForm({ ...form, endDate: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={form.isAllDay}
              onChange={(e) =>
                setForm({ ...form, isAllDay: e.target.checked })
              }
              className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-gray-700">
              All Day Event
            </span>
          </label>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              rows={3}
              placeholder="Event details..."
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {saving && <Loader2 size={16} className="animate-spin" />}
              {editEvent ? "Update Event" : "Create Event"}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
