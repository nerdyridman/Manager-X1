"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Shuffle,
  Save,
  Check,
  Users,
  ArrowLeftRight,
  Loader2,
  AlertCircle,
  Zap,
} from "lucide-react";
import StatusBadge from "@/components/ui/StatusBadge";
import SkeletonCard from "@/components/ui/SkeletonCard";

interface Player {
  id: number;
  name: string;
  number: number;
  position: string;
  status: string;
}

interface MatchOption {
  id: number;
  opponent: string;
  date: string;
  competition: string;
  isHome: boolean;
}

interface SquadSelection {
  playerId: number;
  isStarter: boolean;
  playerName: string;
  playerNumber: number;
  playerPosition: string;
  playerStatus: string;
}

export default function SquadPage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [matches, setMatches] = useState<MatchOption[]>([]);
  const [selectedMatchId, setSelectedMatchId] = useState<number | null>(null);
  const [starters, setStarters] = useState<number[]>([]);
  const [subs, setSubs] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const fetchData = useCallback(async () => {
    const [playersRes, matchesRes] = await Promise.all([
      fetch("/api/players"),
      fetch("/api/matches"),
    ]);

    if (playersRes.ok) {
      const data = await playersRes.json();
      setPlayers(data);
    }

    if (matchesRes.ok) {
      const data = await matchesRes.json();
      const upcoming = data.filter(
        (m: MatchOption & { status: string }) => m.status === "upcoming"
      );
      setMatches(upcoming);
      if (upcoming.length > 0 && !selectedMatchId) {
        setSelectedMatchId(upcoming[0].id);
      }
    }

    setLoading(false);
  }, [selectedMatchId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Load existing squad when match changes
  useEffect(() => {
    if (!selectedMatchId) return;
    const loadSquad = async () => {
      const res = await fetch(`/api/matches/${selectedMatchId}/squad`);
      if (res.ok) {
        const data: SquadSelection[] = await res.json();
        setStarters(
          data.filter((s) => s.isStarter).map((s) => s.playerId)
        );
        setSubs(
          data.filter((s) => !s.isStarter).map((s) => s.playerId)
        );
      }
    };
    loadSquad();
  }, [selectedMatchId]);

  const availablePlayers = players.filter((p) => p.status === "available");
  const unavailablePlayers = players.filter((p) => p.status !== "available");

  const toggleStarter = (playerId: number) => {
    setSaved(false);
    if (starters.includes(playerId)) {
      setStarters(starters.filter((id) => id !== playerId));
    } else if (subs.includes(playerId)) {
      setSubs(subs.filter((id) => id !== playerId));
      if (starters.length < 11) {
        setStarters([...starters, playerId]);
      }
    } else if (starters.length < 11) {
      setStarters([...starters, playerId]);
    } else {
      setSubs([...subs, playerId]);
    }
  };

  const toggleSub = (playerId: number) => {
    setSaved(false);
    if (subs.includes(playerId)) {
      setSubs(subs.filter((id) => id !== playerId));
    } else if (starters.includes(playerId)) {
      setStarters(starters.filter((id) => id !== playerId));
      setSubs([...subs, playerId]);
    } else {
      setSubs([...subs, playerId]);
    }
  };

  const autoGenerate = () => {
    setSaved(false);
    const available = [...availablePlayers];
    const shuffled = available.sort(() => Math.random() - 0.5);

    // Try to build a balanced 11
    const gks = shuffled.filter((p) => p.position === "goalkeeper");
    const defs = shuffled.filter((p) => p.position === "defender");
    const mids = shuffled.filter((p) => p.position === "midfielder");
    const fwds = shuffled.filter((p) => p.position === "forward");

    const selected: number[] = [];
    // 1 GK
    if (gks.length > 0) selected.push(gks[0].id);
    // 4 DEF
    defs.slice(0, 4).forEach((p) => selected.push(p.id));
    // 3 MID
    mids.slice(0, 3).forEach((p) => selected.push(p.id));
    // 3 FWD
    fwds.slice(0, 3).forEach((p) => selected.push(p.id));

    // Fill remaining from whoever's left
    const remaining = available.filter((p) => !selected.includes(p.id));
    while (selected.length < 11 && remaining.length > 0) {
      selected.push(remaining.shift()!.id);
    }

    setStarters(selected.slice(0, 11));
    const restIds = available
      .filter((p) => !selected.includes(p.id))
      .map((p) => p.id)
      .slice(0, 7);
    setSubs(restIds);
  };

  const handleSave = async () => {
    if (!selectedMatchId) return;
    setSaving(true);

    const selections = [
      ...starters.map((id) => ({ playerId: id, isStarter: true })),
      ...subs.map((id) => ({ playerId: id, isStarter: false })),
    ];

    const res = await fetch(`/api/matches/${selectedMatchId}/squad`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ selections }),
    });

    if (res.ok) {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }
    setSaving(false);
  };

  const getPlayerById = (id: number) => players.find((p) => p.id === id);

  const positionIcons: Record<string, string> = {
    goalkeeper: "🧤",
    defender: "🛡️",
    midfielder: "⚙️",
    forward: "⚡",
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-gray-200 rounded w-56 animate-pulse-subtle" />
        <SkeletonCard count={5} />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Squad Generator</h1>
          <p className="text-gray-500 mt-1">
            Select your squad for the next match
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={autoGenerate}
            className="flex items-center gap-2 px-4 py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl font-medium transition-colors"
          >
            <Zap size={16} />
            Auto Generate
          </button>
          <button
            onClick={handleSave}
            disabled={saving || !selectedMatchId}
            className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors shadow-lg shadow-blue-600/20 disabled:opacity-50"
          >
            {saving ? (
              <Loader2 size={16} className="animate-spin" />
            ) : saved ? (
              <Check size={16} />
            ) : (
              <Save size={16} />
            )}
            {saved ? "Saved!" : "Save Squad"}
          </button>
        </div>
      </div>

      {/* Match Selector */}
      {matches.length === 0 ? (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center gap-3">
          <AlertCircle size={20} className="text-amber-600" />
          <p className="text-amber-800 text-sm">
            No upcoming matches. Add a match first to select a squad.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Match
          </label>
          <select
            value={selectedMatchId || ""}
            onChange={(e) => setSelectedMatchId(parseInt(e.target.value))}
            className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
          >
            {matches.map((m) => (
              <option key={m.id} value={m.id}>
                {m.isHome ? "Team" : m.opponent} vs{" "}
                {m.isHome ? m.opponent : "Team"} — {m.competition} (
                {new Date(m.date).toLocaleDateString()})
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Starting XI */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="p-5 border-b border-gray-50">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-gray-900 flex items-center gap-2">
                <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-green-700">XI</span>
                </div>
                Starting XI
              </h3>
              <span className={`text-sm font-semibold ${starters.length === 11 ? "text-green-600" : "text-gray-400"}`}>
                {starters.length}/11
              </span>
            </div>
          </div>
          <div className="divide-y divide-gray-50 max-h-96 overflow-y-auto">
            {starters.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-sm">
                Select players from the available list or click Auto Generate
              </div>
            ) : (
              starters.map((id) => {
                const p = getPlayerById(id);
                if (!p) return null;
                return (
                  <div
                    key={id}
                    className="flex items-center gap-3 p-3 px-5 hover:bg-gray-50 transition-colors group"
                  >
                    <div className="w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center text-xs font-bold">
                      {p.number}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate">
                        {p.name}
                      </p>
                      <p className="text-xs text-gray-400 capitalize">
                        {positionIcons[p.position]} {p.position}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleSub(id)}
                      title="Move to subs"
                      className="p-1 text-gray-300 hover:text-amber-600 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <ArrowLeftRight size={14} />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Substitutes */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="p-5 border-b border-gray-50">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <div className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-amber-700">SUB</span>
              </div>
              Substitutes
              <span className="text-sm font-normal text-gray-400">
                ({subs.length})
              </span>
            </h3>
          </div>
          <div className="divide-y divide-gray-50 max-h-96 overflow-y-auto">
            {subs.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-sm">
                No substitutes selected
              </div>
            ) : (
              subs.map((id) => {
                const p = getPlayerById(id);
                if (!p) return null;
                return (
                  <div
                    key={id}
                    className="flex items-center gap-3 p-3 px-5 hover:bg-gray-50 transition-colors group"
                  >
                    <div className="w-8 h-8 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center text-xs font-bold">
                      {p.number}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate">
                        {p.name}
                      </p>
                      <p className="text-xs text-gray-400 capitalize">
                        {positionIcons[p.position]} {p.position}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleStarter(id)}
                      title="Move to starters"
                      className="p-1 text-gray-300 hover:text-green-600 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <ArrowLeftRight size={14} />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Available Players */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="p-5 border-b border-gray-50">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <Users size={18} className="text-gray-400" />
              Available Players
            </h3>
          </div>
          <div className="divide-y divide-gray-50 max-h-[450px] overflow-y-auto">
            {availablePlayers.map((p) => {
              const isSelected =
                starters.includes(p.id) || subs.includes(p.id);
              return (
                <div
                  key={p.id}
                  onClick={() => toggleStarter(p.id)}
                  className={`flex items-center gap-3 p-3 px-5 cursor-pointer transition-colors ${
                    isSelected
                      ? "bg-blue-50/50 hover:bg-blue-50"
                      : "hover:bg-gray-50"
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                      isSelected
                        ? "bg-blue-600 text-white"
                        : "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {p.number}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`font-medium text-sm truncate ${
                        isSelected ? "text-blue-700" : "text-gray-900"
                      }`}
                    >
                      {p.name}
                    </p>
                    <p className="text-xs text-gray-400 capitalize">
                      {positionIcons[p.position]} {p.position}
                    </p>
                  </div>
                  {isSelected && (
                    <Check size={16} className="text-blue-600" />
                  )}
                </div>
              );
            })}

            {/* Unavailable */}
            {unavailablePlayers.length > 0 && (
              <>
                <div className="px-5 py-3 bg-gray-50">
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    Unavailable
                  </p>
                </div>
                {unavailablePlayers.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center gap-3 p-3 px-5 opacity-50"
                  >
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-xs font-bold text-gray-400">
                      {p.number}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-500 text-sm truncate">
                        {p.name}
                      </p>
                      <p className="text-xs text-gray-400 capitalize">
                        {p.position}
                      </p>
                    </div>
                    <StatusBadge status={p.status} />
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
