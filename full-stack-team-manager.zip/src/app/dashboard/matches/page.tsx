"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Calendar,
  Plus,
  MapPin,
  Trophy,
  Clock,
  Edit2,
  Trash2,
  Loader2,
  Home,
  Plane,
} from "lucide-react";
import Modal from "@/components/ui/Modal";
import StatusBadge from "@/components/ui/StatusBadge";
import EmptyState from "@/components/ui/EmptyState";
import SkeletonCard from "@/components/ui/SkeletonCard";
import { format, isPast } from "date-fns";

interface Match {
  id: number;
  opponent: string;
  venue: string;
  date: string;
  status: string;
  homeScore: number | null;
  awayScore: number | null;
  competition: string;
  isHome: boolean;
  notes: string | null;
}

const matchStatuses = ["upcoming", "live", "completed", "cancelled"];

export default function MatchesPage() {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editMatch, setEditMatch] = useState<Match | null>(null);
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState<"upcoming" | "completed">("upcoming");

  const [form, setForm] = useState({
    opponent: "",
    venue: "",
    date: "",
    status: "upcoming",
    homeScore: "",
    awayScore: "",
    competition: "",
    isHome: true,
    notes: "",
  });

  const fetchMatches = useCallback(async () => {
    const res = await fetch("/api/matches");
    if (res.ok) {
      const data = await res.json();
      setMatches(data);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMatches();
  }, [fetchMatches]);

  const openCreate = () => {
    setEditMatch(null);
    setForm({
      opponent: "",
      venue: "",
      date: "",
      status: "upcoming",
      homeScore: "",
      awayScore: "",
      competition: "",
      isHome: true,
      notes: "",
    });
    setModalOpen(true);
  };

  const openEdit = (match: Match) => {
    setEditMatch(match);
    setForm({
      opponent: match.opponent,
      venue: match.venue,
      date: match.date.slice(0, 16),
      status: match.status,
      homeScore: match.homeScore?.toString() ?? "",
      awayScore: match.awayScore?.toString() ?? "",
      competition: match.competition,
      isHome: match.isHome,
      notes: match.notes || "",
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const body = {
      opponent: form.opponent,
      venue: form.venue,
      date: new Date(form.date).toISOString(),
      status: form.status,
      homeScore: form.homeScore ? parseInt(form.homeScore) : null,
      awayScore: form.awayScore ? parseInt(form.awayScore) : null,
      competition: form.competition,
      isHome: form.isHome,
      notes: form.notes || null,
    };

    if (editMatch) {
      setMatches((prev) =>
        prev.map((m) => (m.id === editMatch.id ? { ...m, ...body } : m))
      );
      setModalOpen(false);

      const res = await fetch(`/api/matches/${editMatch.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) await fetchMatches();
    } else {
      const res = await fetch("/api/matches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        const newMatch = await res.json();
        setMatches((prev) => [newMatch, ...prev]);
      }
      setModalOpen(false);
    }
    setSaving(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this match?")) return;
    setMatches((prev) => prev.filter((m) => m.id !== id));
    const res = await fetch(`/api/matches/${id}`, { method: "DELETE" });
    if (!res.ok) await fetchMatches();
  };

  const upcomingMatches = matches.filter(
    (m) => m.status === "upcoming" || m.status === "live"
  );
  const completedMatches = matches.filter(
    (m) => m.status === "completed" || m.status === "cancelled"
  );
  const displayedMatches =
    tab === "upcoming" ? upcomingMatches : completedMatches;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-200 rounded w-36 animate-pulse-subtle" />
          <div className="h-10 bg-gray-200 rounded w-32 animate-pulse-subtle" />
        </div>
        <SkeletonCard count={4} />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Matches</h1>
          <p className="text-gray-500 mt-1">{matches.length} total matches</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors shadow-lg shadow-blue-600/20"
        >
          <Plus size={18} />
          Add Match
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-xl w-fit">
        <button
          onClick={() => setTab("upcoming")}
          className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
            tab === "upcoming"
              ? "bg-white text-gray-900 shadow-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Upcoming ({upcomingMatches.length})
        </button>
        <button
          onClick={() => setTab("completed")}
          className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
            tab === "completed"
              ? "bg-white text-gray-900 shadow-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Results ({completedMatches.length})
        </button>
      </div>

      {/* Match List */}
      {displayedMatches.length === 0 ? (
        <EmptyState
          icon={<Calendar size={48} />}
          title={
            tab === "upcoming" ? "No upcoming matches" : "No match results yet"
          }
          description={
            tab === "upcoming"
              ? "Schedule your next match to get started"
              : "Complete matches will appear here"
          }
          action={
            tab === "upcoming" ? (
              <button
                onClick={openCreate}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors"
              >
                Schedule Match
              </button>
            ) : undefined
          }
        />
      ) : (
        <div className="space-y-3">
          {displayedMatches.map((match) => (
            <div
              key={match.id}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all p-5 group"
            >
              <div className="flex flex-col md:flex-row md:items-center gap-4">
                {/* Date block */}
                <div className="w-16 h-16 bg-gray-50 rounded-xl flex flex-col items-center justify-center border border-gray-100 shrink-0">
                  <span className="text-xs font-bold text-blue-600">
                    {format(new Date(match.date), "MMM")}
                  </span>
                  <span className="text-xl font-bold text-gray-900 leading-none">
                    {format(new Date(match.date), "d")}
                  </span>
                </div>

                {/* Match info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {match.isHome ? (
                      <Home size={14} className="text-green-600" />
                    ) : (
                      <Plane size={14} className="text-blue-600" />
                    )}
                    <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">
                      {match.isHome ? "Home" : "Away"} •{" "}
                      {match.competition}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900">
                    {match.isHome ? "Team" : match.opponent}{" "}
                    <span className="text-gray-400 font-normal">vs</span>{" "}
                    {match.isHome ? match.opponent : "Team"}
                  </h3>
                  <div className="flex flex-wrap items-center gap-3 mt-1 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Clock size={13} />
                      {format(new Date(match.date), "h:mm a")}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin size={13} />
                      {match.venue}
                    </span>
                  </div>
                </div>

                {/* Score / Status */}
                <div className="flex items-center gap-4">
                  {match.status === "completed" && (
                    <div className="text-center">
                      <p className="text-2xl font-bold text-gray-900">
                        {match.homeScore} - {match.awayScore}
                      </p>
                      <span
                        className={`text-xs font-bold ${
                          (match.isHome &&
                            (match.homeScore ?? 0) > (match.awayScore ?? 0)) ||
                          (!match.isHome &&
                            (match.awayScore ?? 0) > (match.homeScore ?? 0))
                            ? "text-emerald-600"
                            : (match.homeScore ?? 0) === (match.awayScore ?? 0)
                            ? "text-amber-600"
                            : "text-red-600"
                        }`}
                      >
                        {(match.isHome &&
                          (match.homeScore ?? 0) > (match.awayScore ?? 0)) ||
                        (!match.isHome &&
                          (match.awayScore ?? 0) > (match.homeScore ?? 0))
                          ? "WIN"
                          : (match.homeScore ?? 0) === (match.awayScore ?? 0)
                          ? "DRAW"
                          : "LOSS"}
                      </span>
                    </div>
                  )}
                  {match.status !== "completed" && (
                    <StatusBadge status={match.status} />
                  )}

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEdit(match)}
                      className="p-2 hover:bg-blue-50 rounded-lg text-blue-600 transition-colors"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => handleDelete(match.id)}
                      className="p-2 hover:bg-red-50 rounded-lg text-red-500 transition-colors"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editMatch ? "Edit Match" : "Schedule Match"}
        size="lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Opponent *
              </label>
              <input
                type="text"
                value={form.opponent}
                onChange={(e) => setForm({ ...form, opponent: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Competition *
              </label>
              <input
                type="text"
                value={form.competition}
                onChange={(e) =>
                  setForm({ ...form, competition: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
                placeholder="League, Cup, Friendly..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date & Time *
              </label>
              <input
                type="datetime-local"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Venue *
              </label>
              <input
                type="text"
                value={form.venue}
                onChange={(e) => setForm({ ...form, venue: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              >
                {matchStatuses.map((s) => (
                  <option key={s} value={s}>
                    {s.charAt(0).toUpperCase() + s.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <label className="flex items-center gap-2 cursor-pointer py-2.5">
                <input
                  type="checkbox"
                  checked={form.isHome}
                  onChange={(e) =>
                    setForm({ ...form, isHome: e.target.checked })
                  }
                  className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm font-medium text-gray-700">
                  Home Game
                </span>
              </label>
            </div>
          </div>

          {form.status === "completed" && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Home Score
                </label>
                <input
                  type="number"
                  value={form.homeScore}
                  onChange={(e) =>
                    setForm({ ...form, homeScore: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                  min={0}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Away Score
                </label>
                <input
                  type="number"
                  value={form.awayScore}
                  onChange={(e) =>
                    setForm({ ...form, awayScore: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                  min={0}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              rows={2}
              placeholder="Any additional notes..."
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {saving && <Loader2 size={16} className="animate-spin" />}
              {editMatch ? "Update Match" : "Schedule Match"}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
