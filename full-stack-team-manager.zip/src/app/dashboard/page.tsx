"use client";

import { useState, useEffect } from "react";
import {
  Users,
  UserCheck,
  HeartPulse,
  Ban,
  Calendar,
  Clock,
  MapPin,
  Trophy,
  ArrowRight,
  TrendingUp,
} from "lucide-react";
import StatusBadge from "@/components/ui/StatusBadge";
import SkeletonCard from "@/components/ui/SkeletonCard";
import { format, formatDistanceToNow } from "date-fns";
import { useRouter } from "next/navigation";

interface DashboardData {
  stats: {
    totalPlayers: number;
    availablePlayers: number;
    injuredPlayers: number;
    suspendedPlayers: number;
  };
  nextMatch: {
    id: number;
    opponent: string;
    venue: string;
    date: string;
    competition: string;
    isHome: boolean;
  } | null;
  upcomingMatches: Array<{
    id: number;
    opponent: string;
    venue: string;
    date: string;
    competition: string;
    isHome: boolean;
    status: string;
  }>;
  recentMatches: Array<{
    id: number;
    opponent: string;
    date: string;
    competition: string;
    isHome: boolean;
    homeScore: number | null;
    awayScore: number | null;
    status: string;
  }>;
  upcomingEvents: Array<{
    id: number;
    title: string;
    date: string;
    type: string;
    location: string | null;
    isAllDay: boolean;
  }>;
  injuredPlayersList: Array<{
    id: number;
    name: string;
    number: number;
    position: string;
    injuryNote: string | null;
  }>;
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    fetch("/api/dashboard")
      .then((res) => res.json())
      .then((d) => {
        setData(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <div className="h-8 bg-gray-200 rounded w-48 mb-2 animate-pulse-subtle" />
          <div className="h-4 bg-gray-100 rounded w-72 animate-pulse-subtle" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white rounded-2xl p-6 animate-pulse-subtle">
              <div className="h-4 bg-gray-200 rounded w-24 mb-3" />
              <div className="h-8 bg-gray-200 rounded w-16" />
            </div>
          ))}
        </div>
        <SkeletonCard count={3} />
      </div>
    );
  }

  if (!data) return null;

  const statCards = [
    {
      label: "Total Players",
      value: data.stats.totalPlayers,
      icon: Users,
      color: "from-blue-500 to-blue-600",
      bg: "bg-blue-50",
    },
    {
      label: "Available",
      value: data.stats.availablePlayers,
      icon: UserCheck,
      color: "from-emerald-500 to-emerald-600",
      bg: "bg-emerald-50",
    },
    {
      label: "Injured",
      value: data.stats.injuredPlayers,
      icon: HeartPulse,
      color: "from-red-500 to-red-600",
      bg: "bg-red-50",
    },
    {
      label: "Suspended",
      value: data.stats.suspendedPlayers,
      icon: Ban,
      color: "from-amber-500 to-amber-600",
      bg: "bg-amber-50",
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back. Here&apos;s your team overview.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-500">
                  {stat.label}
                </span>
                <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center`}>
                  <Icon size={20} className={`bg-gradient-to-r ${stat.color} bg-clip-text`} style={{ color: stat.color.includes('blue') ? '#3b82f6' : stat.color.includes('emerald') ? '#10b981' : stat.color.includes('red') ? '#ef4444' : '#f59e0b' }} />
                </div>
              </div>
              <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
            </div>
          );
        })}
      </div>

      {/* Next Match Banner */}
      {data.nextMatch && (
        <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 rounded-2xl p-6 md:p-8 text-white shadow-xl shadow-blue-600/20">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Trophy size={16} className="text-blue-200" />
                <span className="text-blue-200 text-sm font-medium">
                  Next Match • {data.nextMatch.competition}
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">
                {data.nextMatch.isHome ? "Team" : data.nextMatch.opponent} vs{" "}
                {data.nextMatch.isHome ? data.nextMatch.opponent : "Team"}
              </h2>
              <div className="flex flex-wrap items-center gap-4 text-blue-100">
                <span className="flex items-center gap-1.5">
                  <Calendar size={14} />
                  {format(new Date(data.nextMatch.date), "EEEE, MMM d, yyyy")}
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock size={14} />
                  {format(new Date(data.nextMatch.date), "h:mm a")}
                </span>
                <span className="flex items-center gap-1.5">
                  <MapPin size={14} />
                  {data.nextMatch.venue}
                </span>
              </div>
              <p className="text-blue-200 text-sm mt-2">
                {formatDistanceToNow(new Date(data.nextMatch.date), {
                  addSuffix: true,
                })}
              </p>
            </div>
            <button
              onClick={() => router.push("/dashboard/squad")}
              className="flex items-center gap-2 px-6 py-3 bg-white/20 hover:bg-white/30 rounded-xl font-semibold transition-all backdrop-blur-sm"
            >
              <Swords size={18} />
              Select Squad
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Results */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between p-6 border-b border-gray-50">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <TrendingUp size={18} className="text-blue-600" />
              Recent Results
            </h3>
            <button
              onClick={() => router.push("/dashboard/matches")}
              className="text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              View All
            </button>
          </div>
          <div className="divide-y divide-gray-50">
            {data.recentMatches.map((match) => (
              <div
                key={match.id}
                className="flex items-center justify-between p-5 hover:bg-gray-50/50 transition-colors"
              >
                <div>
                  <p className="font-semibold text-gray-900">
                    {match.isHome ? "Team" : match.opponent} vs{" "}
                    {match.isHome ? match.opponent : "Team"}
                  </p>
                  <p className="text-sm text-gray-500">
                    {match.competition} •{" "}
                    {format(new Date(match.date), "MMM d")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-gray-900">
                    {match.homeScore} - {match.awayScore}
                  </p>
                  <span
                    className={`text-xs font-semibold ${
                      (match.isHome && (match.homeScore ?? 0) > (match.awayScore ?? 0)) ||
                      (!match.isHome && (match.awayScore ?? 0) > (match.homeScore ?? 0))
                        ? "text-emerald-600"
                        : (match.homeScore ?? 0) === (match.awayScore ?? 0)
                        ? "text-amber-600"
                        : "text-red-600"
                    }`}
                  >
                    {(match.isHome && (match.homeScore ?? 0) > (match.awayScore ?? 0)) ||
                    (!match.isHome && (match.awayScore ?? 0) > (match.homeScore ?? 0))
                      ? "WIN"
                      : (match.homeScore ?? 0) === (match.awayScore ?? 0)
                      ? "DRAW"
                      : "LOSS"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between p-6 border-b border-gray-50">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <Calendar size={18} className="text-purple-600" />
              Upcoming Events
            </h3>
            <button
              onClick={() => router.push("/dashboard/events")}
              className="text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              View All
            </button>
          </div>
          <div className="divide-y divide-gray-50">
            {data.upcomingEvents.map((event) => (
              <div
                key={event.id}
                className="flex items-center gap-4 p-5 hover:bg-gray-50/50 transition-colors"
              >
                <div className="w-12 h-12 bg-gray-50 rounded-xl flex flex-col items-center justify-center border border-gray-100">
                  <span className="text-xs font-bold text-blue-600">
                    {format(new Date(event.date), "MMM")}
                  </span>
                  <span className="text-lg font-bold text-gray-900 leading-none">
                    {format(new Date(event.date), "d")}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900 truncate">
                    {event.title}
                  </p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <StatusBadge status={event.type} />
                    {event.location && (
                      <span className="text-xs text-gray-400 truncate">
                        {event.location}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Injury Report */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm lg:col-span-2">
          <div className="flex items-center justify-between p-6 border-b border-gray-50">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <HeartPulse size={18} className="text-red-500" />
              Injury Report
            </h3>
          </div>
          {data.injuredPlayersList.length === 0 ? (
            <div className="p-8 text-center text-gray-400">
              <HeartPulse size={32} className="mx-auto mb-2 text-gray-300" />
              <p className="font-medium">No injuries</p>
              <p className="text-sm">All players are fit and available</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {data.injuredPlayersList.map((player) => (
                <div
                  key={player.id}
                  className="flex items-center gap-4 p-5 hover:bg-gray-50/50 transition-colors"
                >
                  <div className="w-11 h-11 bg-red-50 rounded-full flex items-center justify-center text-red-600 font-bold text-sm">
                    #{player.number}
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{player.name}</p>
                    <p className="text-sm text-gray-500 capitalize">
                      {player.position}
                    </p>
                  </div>
                  <div className="text-right">
                    <StatusBadge status="injured" />
                    {player.injuryNote && (
                      <p className="text-xs text-gray-400 mt-1 max-w-xs truncate">
                        {player.injuryNote}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Swords({ size, className }: { size: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5" />
      <line x1="13" y1="19" x2="19" y2="13" />
      <line x1="16" y1="16" x2="20" y2="20" />
      <line x1="19" y1="21" x2="21" y2="19" />
      <polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5" />
      <line x1="5" y1="14" x2="9" y2="18" />
      <line x1="7" y1="17" x2="4" y2="20" />
      <line x1="3" y1="19" x2="5" y2="21" />
    </svg>
  );
}
