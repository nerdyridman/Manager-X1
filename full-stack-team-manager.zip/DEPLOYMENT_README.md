# Manager X - Deployment Guide

## Quick Start (15 minutes total)

### Prerequisites
- Gmail account
- GitHub account (free) - https://github.com
- Neon account (free) - https://neon.tech
- Vercel account (free) - https://vercel.com

---

## Step 1: Set Up Database (Neon)

1. Go to https://neon.tech and sign in with Google
2. Click "Create Project" → Name it "manager-x"
3. Copy your connection string (looks like `postgresql://user:pass@host/db`)

---

## Step 2: Upload to GitHub

1. Create a new repository at https://github.com/new
2. Name it `manager-x` (public or private)
3. Upload all the project files to this repository

---

## Step 3: Deploy to Vercel

1. Go to https://vercel.com and sign in with GitHub
2. Click "Add New Project"
3. Import your `manager-x` repository
4. **IMPORTANT:** Before deploying, add Environment Variable:
   - Click "Environment Variables"
   - Add: `DATABASE_URL` = `your-neon-connection-string`
5. Click "Deploy"
6. Wait 2-3 minutes for build to complete

---

## Step 4: Initialize Database

After deployment, visit:
```
https://your-app-name.vercel.app/api/seed
```

This creates the tables and adds demo data.

---

## Step 5: Use Your App!

1. Go to your app URL: `https://your-app-name.vercel.app`
2. Register with your Gmail (or any email)
3. Start managing your team!

---

## Login Credentials (Demo Account)

After seeding, you can use:
- Email: `alex@managerx.com`
- Password: `password123`

Or register your own account!

---

## Sharing With Others

Just share your Vercel URL:
```
https://your-app-name.vercel.app
```

Anyone can register and use the app. All data is shared (everyone sees the same players, matches, etc.)

---

## Troubleshooting

### "Database connection error"
- Make sure DATABASE_URL is set correctly in Vercel Environment Variables
- The connection string must include `?sslmode=require` at the end

### "Tables don't exist"
- Visit `/api/seed` to create tables and demo data

### Changes not saving
- Check browser console for errors
- Make sure you're logged in

---

## Need Separate Data Per User?

The current app shares all data between users (team collaboration).
If you need private data per user, let me know and I can modify the schema.

---

## Tech Stack

- **Frontend:** Next.js 16, React 19, Tailwind CSS
- **Backend:** Next.js API Routes
- **Database:** PostgreSQL via Drizzle ORM
- **Auth:** JWT with HTTP-only cookies
- **Hosting:** Vercel (serverless)
